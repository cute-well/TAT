"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { AppHeader } from "@/components/app-header"
import { DocumentList } from "@/components/document-list"
import { DocumentDetails } from "@/components/document-details"
import { UploadModal } from "@/components/upload-modal"
import { AnalyticsView } from "@/components/analytics-view"
import { Document } from "@/components/document-card"

export default function Home() {
  const [activeView, setActiveView] = useState("all-documents")
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null)
  const [uploadModalOpen, setUploadModalOpen] = useState(false)

  const handleDocumentSelect = (doc: Document) => {
    setSelectedDocument(doc)
  }

  const handleCloseDetails = () => {
    setSelectedDocument(null)
  }

  return (
    <div className="flex h-screen bg-background">
      <AppSidebar activeView={activeView} onViewChange={setActiveView} />

      <div className="flex flex-1 flex-col">
        <AppHeader onUploadClick={() => setUploadModalOpen(true)} />

        <main className="flex flex-1 overflow-hidden">
          {activeView === "analytics" ? (
            <div className="flex-1">
              <AnalyticsView />
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-hidden">
                <DocumentList
                  onDocumentSelect={handleDocumentSelect}
                  selectedDocument={selectedDocument}
                />
              </div>

              {selectedDocument && (
                <DocumentDetails
                  document={selectedDocument}
                  onClose={handleCloseDetails}
                />
              )}
            </>
          )}
        </main>
      </div>

      <UploadModal open={uploadModalOpen} onOpenChange={setUploadModalOpen} />
    </div>
  )
}
